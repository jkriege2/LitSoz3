//========================================================================
//
// ImgWriter.cpp
//
// This file is licensed under the GPLv2 or later
//
// Copyright (C) 2009 Albert Astals Cid <aacid@kde.org>
//
//========================================================================

#include "ImgWriter.h"

ImgWriter::~ImgWriter()
{
}
