CSL Styles Distribution
======================

This repository is a copy of [citation-style-language/styles](https://github.com/citation-style-language/styles), refreshed on every commit, with each file's &lt;updated&gt; timestamp set to the file's last git commit time.

Licensing
---------
Please refer to https://github.com/citation-style-language/styles.
